APEX DIGITAL SPACE — PORTFOLIO IMAGE ASSETS

Copy these four files into the repository's assets/ folder:
- web-development.jpg — website development / coding workspace
- it-support.jpg — computer hardware maintenance / IT support
- digital-work.jpg — laptop-based digital work
- forex-analysis.jpg — trading analysis workspace

Recommended portfolio mappings:
- Work & Documentation: use all four images in the order above.
- Projects: Apex Bot -> forex-analysis.jpg
- Apex Digital Space Portfolio -> web-development.jpg
- Linux & System Administration -> it-support.jpg
- Community Technology Work -> digital-work.jpg

The existing portrait should remain unchanged.
